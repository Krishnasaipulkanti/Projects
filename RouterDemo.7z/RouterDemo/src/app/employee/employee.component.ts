import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
employees:IEmployee []=[
{
  eid:1001,
  ename:'john',
  esal:5000
},
{ eid:1002,
  ename:'david',
  esal:4000

}
];
  constructor() { }

  ngOnInit() {
  }
delet(emp:IEmployee){
  let arr=this.employees.filter(p=>p.eid!=emp.eid);
  this.employees=arr;
}
}

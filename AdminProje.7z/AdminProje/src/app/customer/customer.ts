export interface customer{  
    customerId:number;
contactNo:string;
 name:string;
email:string;
orderId:number;
productName:string;
productPrice:number
}
import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from '../adminservice.service';
import{HttpClient} from '@angular/common/http';
import { customer } from './customer';
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
cus:customer[];
customerId:number;
contactNo:string;
 name:string;
email:string;
orderId:number;
productName:string;
productPrice:number
  constructor(private service:AdminserviceService,private http:HttpClient) { }

  ngOnInit() {
    this.http.get("http://localhost:9191/cuss").subscribe((data)=>this.display(data))
  }
  display(data)
  {
  this.cus=data;
  }
}

import { Injectable } from '@angular/core';
import {HttpClientModule,HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {admin} from './admincreate/admin'
import { customer } from './customer/customer';
import { merchant } from './merchant/merchant';
@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {
  private url:string;
  private url1:string;
private url2:string;
  
 
 
 
 
  constructor(private http:HttpClient) { 
    this.url="http://localhost:9191/users";
    this.url1="http://localhost:9191/cuss";
    this.url2="http://localhost:9191/merr"
  }
   /* getAdmin():Observable<admin []>
  {
  
   return this.http.get<admin []>(this.url);
  } */
 

  public save(admins: admin) {
    return this.http.post<admin>(this.url, admins);
  }


   getCus():Observable<customer []>
{
  return this.http.get<customer[]>(this.url1);
}
getmer():Observable<merchant []>
{
  return this.http.get<merchant[]>(this.url2);
} 
}

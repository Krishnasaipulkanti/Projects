import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Route,RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { MerchantComponent } from './merchant/merchant.component';
import { AdmincreateComponent } from './admincreate/admincreate.component';
import {HttpClientModule} from '@angular/common/http';
import { AdminserviceService } from './adminservice.service';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    MerchantComponent,
    AdmincreateComponent
  ],
  imports: [
    BrowserModule, FormsModule,ReactiveFormsModule,HttpClientModule,Ng2SearchPipeModule,RouterModule.forRoot([
      { path:'customer',
       component:CustomerComponent
     },
     {
       path:'merchant',
       component:MerchantComponent
     },
     {
       path:'admincreate',
       component:AdmincreateComponent
     }
     ]),
  ],
  providers: [AdminserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }

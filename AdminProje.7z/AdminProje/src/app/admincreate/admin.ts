export class admin{
    email:string;
    name:string;
    password:string;
    question:string;
    answer:string;

}
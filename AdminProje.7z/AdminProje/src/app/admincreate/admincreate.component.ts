import { Component, OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import {AdminserviceService} from '../adminservice.service';
import {admin} from './admin';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-admincreate',
  templateUrl: './admincreate.component.html',
  styleUrls: ['./admincreate.component.css']
})
export class AdmincreateComponent  {
admins:admin;
  userForm: FormGroup;

  constructor(private service:AdminserviceService,private http:HttpClient) { 
    this.admins= new admin();
  }

  /* ngOnInit() {
    
    this.userForm=new FormGroup ( {
      email:new FormControl('',[Validators.required,Validators.email]),
name:new FormControl('',[Validators.required,Validators.minLength(6)]),
password:new FormControl('',[Validators.required,Validators.minLength(8)]),
question:new FormControl('',[Validators.required]),
answer:new FormControl('',[Validators.required]),

    })
    this.http.get("http://localhost:9191/users").subscribe((data)=>this.display(data))
  } */
 /* 
  display(data)
  {
  this.admins=data;
  } */
 
 
 /*  onSubmit(obj:any){
    alert("Admin Created Successfully")
    this.admins.push({email:obj.email,name:obj.name,password:obj.password,question:obj.question,answer:obj.answer});
  
    
  } */
  onSubmit(obj:any) {
    
   
     this.service.save(this.admins).subscribe(result => this.gotoUserList());
  }

  gotoUserList() {
    alert("Admin Created Successfully")
  }
}


import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from '../adminservice.service';
import{HttpClient} from '@angular/common/http';
import { merchant } from './merchant';
@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {
mer:merchant[];
merchantName:string;
merchantId:number;
productName:string;
productCatogery:string;
productQuantity:number;
productId:number;
productPrice:number;
  constructor(private service:AdminserviceService,private http:HttpClient) { }

  ngOnInit() {
    this.http.get("http://localhost:9191/merr").subscribe((data)=>this.display(data))
  }
  display(data)
  {
  this.mer=data;
  }
}

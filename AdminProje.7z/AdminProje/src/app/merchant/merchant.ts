export interface merchant{
    merchantName:string;
merchantId:number;
productName:string;
productCatogery:string;
productQuantity:number;
productId:number;
productPrice:number
}
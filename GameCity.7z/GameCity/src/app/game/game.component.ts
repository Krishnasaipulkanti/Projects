import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Igame } from './game';
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {
 
game:Igame[];
gameId:number;
gameName:string;
gamePrice:number;
balance:number=600;
  constructor(private service:ServiceService, private http:HttpClient) { }

  ngOnInit() {
   
    this.http.get("assets/GameList.json").subscribe((data)=>this.display(data))
  }
  display(data)
  {
  this.game=data;
  }
  play(game:Igame){
    
if(this.balance>game.gamePrice){
    
    this.balance=(this.balance-game.gamePrice);
    alert("Thank you for playing"+ " "+game.gameName+" and your remaining balance is"+" "+ this.balance)
    }
    else
    {
      alert("Thank you for playing"+ " "+game.gameName+" and we are unable to process your request due to insuffecient funds")
    }
  }

}

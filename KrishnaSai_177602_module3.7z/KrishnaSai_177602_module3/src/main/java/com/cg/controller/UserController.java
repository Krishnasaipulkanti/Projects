package com.cg.controller;


import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.UserRepository;
import com.cg.entity.User1;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

UserRepository userRepository;
public UserController(UserRepository userRepository) {
	super();
	this.userRepository = userRepository;
}
//	@RequestMapping(value="/create/{email}/{name}/{password}/{question}/{answer}", method = RequestMethod.POST,headers="Accept=application/json")
//	public User1 createAccount(@PathVariable String email,@PathVariable String name,@PathVariable String password,@PathVariable String question,@PathVariable String answer) {
//		
//		user.setEmail(email);
//		user.setName(name);
//		user.setPassword(password);
//		user.setQuestion(question);
//		user.setAnswer(answer);
//		
//		return usrrep.save(user);
//
//		
//	}
	@PostMapping("/users")

    void addUser(@RequestBody User1 user1) {

		userRepository.save(user1);

    }
	
}
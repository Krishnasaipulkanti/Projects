package com.cg.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.MerchantRepository;
import com.cg.entity.Customer1;
import com.cg.entity.Merchant1;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class MerchantController {

	MerchantRepository merchantRepository;

	public MerchantController(MerchantRepository merchantRepository) {
		super();
		this.merchantRepository = merchantRepository;
	}
	
	@GetMapping("/merr")
    public List<Merchant1> getUsers() {
        return (List<Merchant1>) merchantRepository.findAll();
    }
	
	
}

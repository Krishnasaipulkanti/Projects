package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="Merch_info")
public class Merchant1 {

	@Id
	@Column(length=20)
	private int merchantId;
	@Column(length=20)
	private String merchantName;
	@Column(length=20)
	private String productName;
	@Column(length=20)
	private String productCatogery;
	@Column(length=20)
private int productQuantity;
	@Column(length=20)
	private int productId;
	@Column(length=20)
private int	productPrice;
	public Merchant1(int merchantId, String merchantName, String productName, String productCatogery,
			int productQuantity, int productId, int productPrice) {
		super();
		this.merchantId = merchantId;
		this.merchantName = merchantName;
		this.productName = productName;
		this.productCatogery = productCatogery;
		this.productQuantity = productQuantity;
		this.productId = productId;
		this.productPrice = productPrice;
	}
	public Merchant1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCatogery() {
		return productCatogery;
	}
	public void setProductCatogery(String productCatogery) {
		this.productCatogery = productCatogery;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Merchant1 [merchantId=" + merchantId + ", merchantName=" + merchantName + ", productName=" + productName
				+ ", productCatogery=" + productCatogery + ", productQuantity=" + productQuantity + ", productId="
				+ productId + ", productPrice=" + productPrice + "]";
	}
	
	
}




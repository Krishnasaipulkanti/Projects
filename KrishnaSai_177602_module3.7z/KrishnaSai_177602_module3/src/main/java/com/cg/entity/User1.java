package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="Admin_info")
public class User1 {
	@Id
	@Column(length=25)
	private String email;
	@Column(length=25)
	private String name;
	@Column(length=25)
	private String password;
	@Column(length=30)
	private String question;
	@Column(length=25)
	private String answer;
	public User1(String email, String name, String password, String question, String answer) {
		super();
		
		this.email = email;
		this.name = name;
		this.password = password;
		this.question = question;
		this.answer = answer;
	}
	public User1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "User [email=" + email + ", name=" + name + ", password=" + password + ", question="
				+ question + ", answer=" + answer + "]";
	}




}
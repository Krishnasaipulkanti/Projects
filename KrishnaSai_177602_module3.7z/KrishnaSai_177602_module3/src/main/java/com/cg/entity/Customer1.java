package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="Cust_info")
public class Customer1 {
	@Id
	@Column(length=20)
	private int customerId;
	@Column(length=20)
	private String contactNo;
	@Column(length=20)
	private String name;
	@Column(length=30)
	private String email;
	@Column(length=20)
	private int orderId;
	@Column(length=20)
	private String productName;
	@Column(length=20)
	private int productPrice;
	public Customer1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer1(int customerId, String contactNo, String name, String email, int orderId, String productName,
			int productPrice) {
		super();
		this.customerId = customerId;
		this.contactNo = contactNo;
		this.name = name;
		this.email = email;
		this.orderId = orderId;
		this.productName = productName;
		this.productPrice = productPrice;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", contactNo=" + contactNo + ", name=" + name + ", email=" + email
				+ ", orderId=" + orderId + ", productName=" + productName + ", productPrice=" + productPrice + "]";
	}
	
	
	
	
}
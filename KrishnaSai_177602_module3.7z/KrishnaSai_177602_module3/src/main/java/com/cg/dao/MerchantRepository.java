package com.cg.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.entity.Merchant1;
import com.cg.entity.User1;

@Repository
public interface MerchantRepository extends CrudRepository<Merchant1, Integer>{

}

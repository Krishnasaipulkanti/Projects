package com.cg.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.entity.Customer1;


@Repository
public interface CustomerRepository extends CrudRepository<Customer1, Integer>{

}

package com.cg.ParallelProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.ParallelProject.enity.Account;
import com.cg.ParallelProject.service.IAccount;

@RestController
public class AccountController {
	Account account= new Account();
	@Autowired
	IAccount accservice;
	
	
	@RequestMapping(value="/create/{name}/{amount}/{contact}/{type}", method = RequestMethod.POST,headers="Accept=application/json")
	public String createAccount(@PathVariable String name,@PathVariable int amount,@PathVariable String contact,@PathVariable String type) {
		
		account.setName(name);
		account.setBalance(amount);
		account.setContactNo(contact);
		account.setAccountType(type);
		account = accservice.createAccount(account);
		String res="Added Successfully and Trainee Id is: "+account.getAccountNo();
		return res;

		
	}
	@GetMapping(value="/showbalance/{accnum}")
	public String show(@PathVariable int accnum) {
		int balance= accservice.showbalance(accnum);
		String res="Account balance is: "+balance;
		return res;
	}
	@PostMapping(value="/deposit/{accnum}/{amount}")
	public String deposit(@PathVariable int accnum,@PathVariable int amount) {
		int bal=accservice.deposit(accnum, amount);
		String res="Account balance is: "+bal;
		return res;
		
	}
	@PostMapping(value = "/withdraw/{accnum}/{amount}")
	public String withdraw(@PathVariable int accnum,@PathVariable int amount) {
		System.out.println(accnum+"--"+amount);
		int bal=accservice.withdraw(accnum, amount);
		String res="Account balance is: "+bal;
		return res;
		
		
		}
	@PostMapping(value="/fundtransfer/{accnum}/{accnum1}/{amount}")
	public String fundT(@PathVariable int accnum,@PathVariable int accnum1,@PathVariable int amount) {
		accservice.transfer(accnum,accnum1, amount);
		int bala=accservice.showbalance(accnum);
		String res="available balance is"+bala;
		return res;
	}
}

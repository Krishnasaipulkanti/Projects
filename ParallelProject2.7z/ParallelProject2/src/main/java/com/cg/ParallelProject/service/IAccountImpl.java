package com.cg.ParallelProject.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cg.ParallelProject.dao.AccountRepository;
import com.cg.ParallelProject.enity.Account;

@Service
public class IAccountImpl implements IAccount{
	@Autowired
AccountRepository accrepo;
	
	Account account= new Account();
	@Override
	public Account createAccount(Account account) {
		Random rand = new Random();
		int acNo = rand.nextInt(900000000) + 1000000000;
		account.setAccountNo(acNo);
		return accrepo.save(account);
	}

	@Override
	public int showbalance(int accnum) {
		
		return accrepo.findById(accnum).get().getBalance();
	}

	@Override
	public int deposit(int accnum, int deposit) {
		account=accrepo.findById(accnum).get();
		deposit=account.getBalance()+deposit;
		account.setBalance(deposit);
		
		accrepo.save(account);
		return account.getBalance();
	}

	@Override
	public int withdraw(int accnum, int withdraw) {
		account=accrepo.findById(accnum).get();
		if(account.getBalance()<withdraw) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 		 withdraw=account.getBalance()-withdraw;
			account.setBalance(withdraw);
		 accrepo.save(account);
		 return account.getBalance();
		}
			
	}

	@Override
	public int transfer(int accnum,int accnum1, int amount) {
		account=accrepo.findById(accnum).get();
		Account account1=accrepo.findById(accnum1).get();
		if(account.getBalance()<amount) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 int balance = account.getBalance()-amount;
		 account.setBalance(balance);
		int bal=account1.getBalance()+amount;
		account1.setBalance(bal);
		accrepo.save(account1);
		 accrepo.save(account);
		 return account.getBalance();
		}
	}

	@Override
	public String validateAccnum(int accnum) {
		String str;
		account=accrepo.findById(accnum).get();
				if(account!=null) {
					str="account number exists";
			return str;
				}
				else {
					str="account number not exists";
		return str;
				}
	}

}

package com.cg.pizzaorder.entity;

public class Customer {
	private String cusName;
	private String address;
	private String phone;
	public Customer(String cusName, String address, String phone) {
		super();
		this.cusName = cusName;
		this.address = address;
		this.phone = phone;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Customer [cusName=" + cusName + ", address=" + address + ", phone=" + phone + "]";
	}


}

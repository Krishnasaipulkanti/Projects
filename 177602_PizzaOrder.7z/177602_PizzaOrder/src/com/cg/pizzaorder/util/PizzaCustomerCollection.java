package com.cg.pizzaorder.util;

import java.util.HashMap;

import com.cg.pizzaorder.entity.Customer;
import com.cg.pizzaorder.entity.PizzaOrder;

public class PizzaCustomerCollection {
	public static HashMap<Integer,PizzaOrder>piz=new HashMap<Integer,PizzaOrder>();
	static {
		piz.put(123,new PizzaOrder(123,212,300));
		piz.put(124,new PizzaOrder(124,213,300));
		piz.put(125,new PizzaOrder(125,214,300));
		
	}
	public static HashMap<Integer,Customer>cus=new HashMap<Integer,Customer>();
	static {
		cus.put(212,new  Customer("krishna","hyd","8886477538"));
		cus.put(213,new  Customer("chetan","blr","8886477548"));
		cus.put(212,new  Customer("raushan","bhr","8886477558"));
	}
	
	public static int placeOrder(Customer cc,PizzaOrder po) {
		piz.put(po.getOrderId(), po);
	cus.put(po.getCustomerId(), cc);
		return po.getOrderId();
	}
	public static PizzaOrder getOrderDetails(int orderId) {
		return piz.get(orderId);
		//return po;
	}
	/*public static ArrayList<PizzaOrder>po=new ArrayList<PizzaOrder>();
	static {
		po.add(new PizzaOrder(123,212,300));
		po.add(new PizzaOrder(124,213,300));
		po.add(new PizzaOrder(125,214,300));
	}*/
	


}

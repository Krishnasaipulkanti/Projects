package com.cg.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.dao.CustomerBankDaoImp;
import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;

public class CustomerBankServiceImp implements CustomerBankService {

	CustomerBankDaoImp cbdi=new CustomerBankDaoImp();

	@Override
	public BankAccount getAccBalance(int cusAccNumber) throws CustomerAccountException {
	 BankAccount ba=cbdi.getAccBalance(cusAccNumber);
		return ba;
	}

	@Override
	public int createAccount(BankAccount bac,Customer ca) throws CustomerAccountException {
		int cs=cbdi.createAccount(bac,ca);
		return cs;
	}

	@Override
	public boolean validatename(String cusName) throws CustomerAccountException {
		
if(Pattern.matches("[a-zA-Z]{7}",cusName))
{
	return true;
	}
else {
	return false;
}

	}

	@Override
	public boolean validateAddress(String cusAddress) throws CustomerAccountException {
		
		if(Pattern.matches("[a-zA-Z]{7}",cusAddress)) {
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean validateChoice(int choice) throws CustomerAccountException {
		Pattern pattern = Pattern.compile("^[1-2]{1}");
		Matcher cuschoice=pattern.matcher(Integer.toString(choice));
		if(cuschoice.matches()) {
			return true;
		}else {
			return false;
		}
		
		
	}

	@Override
	public BankAccount deposite(int cusAccNumber, int depamount) throws CustomerAccountException {
	BankAccount ba=cbdi.deposite(cusAccNumber, depamount);
		return ba;
	}

	@Override
	public BankAccount withdraw(int cusAccNumber, int withamm) throws CustomerAccountException {
		BankAccount ba=cbdi.withdraw(cusAccNumber, withamm);
		return ba;
	}

	@Override
	public BankAccount fundTransfer(int cusAccNumber, int cusAccNumber1, int trfamm) throws CustomerAccountException {
		BankAccount ba=cbdi.fundTransfer(cusAccNumber, cusAccNumber1, trfamm);
		return ba;
	}

	@Override
	public HashMap<Integer, BankAccount> fetchAllDetails() throws CustomerAccountException {
		HashMap<Integer, BankAccount> hm=cbdi.fetchAllDetails();
		return hm;
	}

	
}

package com.cg.dao;


import java.util.HashMap;

import com.cg.entity.BankAccount;
import com.cg.entity.Customer;
import com.cg.exception.CustomerAccountException;

public interface CustomerBankDao {
	public int createAccount(BankAccount bac,Customer ca) throws CustomerAccountException;
	public BankAccount getAccBalance(int cusAccNumber) throws CustomerAccountException; 
	public  BankAccount deposite(int cusAccNumber,int depamount) throws CustomerAccountException;
	public  BankAccount withdraw(int cusAccNumber,int withamm)  throws CustomerAccountException;
	public  BankAccount fundTransfer(int cusAccNumber,int cusAccNumber1,int trfamm) throws CustomerAccountException;
	public  HashMap<Integer,BankAccount> fetchAllDetails()throws CustomerAccountException;
}

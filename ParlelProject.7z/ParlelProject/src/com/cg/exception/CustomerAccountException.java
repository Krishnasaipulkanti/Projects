package com.cg.exception;

public class CustomerAccountException extends Exception{

	public CustomerAccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
